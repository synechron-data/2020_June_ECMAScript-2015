// Lexical Scoping

// var a = 10;
// console.log(a);

// function test() {
//     console.log("Inside Test", a);
// }
// test();

// function test1() {
//     // var a = 1000;
//     function test2() {
//         // var a = 100;
//         console.log("Inside Test 2", a);
//     }
//     test2();
// }

// test();
// test1();

// Scopes in ES 5
// Global Scope
// Function Scope

// var i = "Hello";
// console.log("Before, i is", i);

// for (var i = 0; i < 5; i++) {
//     console.log("Inside Loop, i is", i);
// }

// for (var _i = 0; _i < 5; _i++) {
//     console.log("Inside Loop, i is", _i);
// }

// function iterate() {
//     for (var i = 0; i < 5; i++) {
//         console.log("Inside Loop, i is", i);
//     }
// }
// iterate();

// IIFE
// (function () {
//     for (var i = 0; i < 5; i++) {
//         console.log("Inside Loop, i is", i);
//     }
// })();

// console.log("After, i is", i);

// ---------------------------------------------------- Scopes in ECMASCRIPT 2015 and above
// Global Scope
// Function Scope
// Block Scope (Only when we use let or const)

var i = "Hello";
console.log("Before, i is", i);

for (let i = 0; i < 5; i++) {
    console.log("Inside Loop, i is", i);
}

console.log("After, i is", i);
