// Block Scoped Variables

// let a = 10;
// console.log(a);
// console.log(typeof a);

// Hoisting - Hoisting is not allowed with let keyword

// a = 10;
// console.log(a);
// let a;

// We cannot recreate a block scoped variable
// let a = 10;
// let a = "Manish";
// console.log(a);

// ----------------------------------------------
// const must be initialized and it cannot be re-initialized

// const env = "development";
// console.log(env);

// env = "production";
// console.log(env);

const person = { id: 1, name: "Manish" };
console.log(person);

// person = {};        // Error

person.name = "Abhijeet";
console.log(person);
