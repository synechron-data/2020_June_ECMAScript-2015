// Immediatly Invoked Function Expression
// function hello() {
//     console.log("Hello World!");
// }

// hello();

// (function () {
//     console.log("Hello World!");
// })();

// (function () {
//     console.log("Hello World!");
// }());

(function (name) {
    console.log("Hello, ", name);
})("Abhijeet");

(function (name) {
    console.log("Hello, ", name);
}("Manish"));
