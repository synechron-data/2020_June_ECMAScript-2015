// import './1_Datatypes/1_Declarations';
// import './1_Datatypes/2_DataTypes';
// import './1_Datatypes/3_ES6_Declarations';
// import './1_Datatypes/4_Scopes';

// import './2_Operators/1_Comparision';
// import './2_Operators/2_Symbols';
// import './2_Operators/3_DataConversion';

// import './3_CertainConditions/1_Loop';
// import './3_CertainConditions/2_Statements';

// import './4_Functions/1_FnCreation';
// import './4_Functions/2_FnParameters';
// import './4_Functions/3_RestAndSpread';
// import './4_Functions/4_PureAndImpureFn';
// import './4_Functions/5_ArrowFunctions';
// import './4_Functions/6_FnAsParameter';
// import './4_Functions/7_FnOverloading';
// import './4_Functions/8_IIFE';
import './4_Functions/9_OverloadingAssignment';