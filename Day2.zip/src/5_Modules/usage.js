// Case 1 - Default Import
// import square from './lib';
// console.log("Result: ", square(20));

// import sqr from './lib';
// console.log("Result: ", sqr(20));

// Case 2 - Multiple Export - Named Imports
// import { square, check } from './lib';
// console.log("Square: ", square(20));
// console.log("Check: ", check(20));

// import * as lib from './lib';
// console.log("Square: ", lib.square(20));
// console.log("Check: ", lib.check(20));

// Case 3 - Default & Named Imports
// import square, { check } from './lib';
// console.log("Square: ", square(20));
// console.log("Check: ", check(20));

import sqr, { check } from './lib';
console.log("Square: ", sqr(20));
console.log("Check: ", check(20));