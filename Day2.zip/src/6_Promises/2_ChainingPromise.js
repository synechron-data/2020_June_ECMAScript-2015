var firstMethod = function () {
    var promise = new Promise(function (resolve, reject) {
        setTimeout(function () {
            console.log('first method completed');
            resolve({ data: 'From first method' });
        }, 2000);
    });
    return promise;
};

var secondMethod = function (someData) {
    var promise = new Promise(function (resolve, reject) {
        setTimeout(function () {
            console.log('second method completed');
            resolve({ first: someData.data, second: 'From second method' });
        }, 2000);
    });
    return promise;
};

var thirdMethod = function (someData) {
    var promise = new Promise(function (resolve, reject) {
        setTimeout(function () {
            console.log('third method completed');
            var data = Object.assign({}, someData);
            data.third = 'From third method';
            resolve(data);
        }, 3000);
    });
    return promise;
};

// firstMethod().then((data) => {
//     secondMethod(data).then((data) => {
//         thirdMethod(data).then((data) => {
//             console.log("Final Result: ", data);
//         });
//     });
// });

firstMethod().then(secondMethod).then(thirdMethod).then((data) => {
    console.log("Final Result: ", data);
});

