import localAPI from "./localAPI";

var button = document.createElement("button");
button.innerHTML = "Get Data";

var body = document.getElementsByTagName("body")[0];
body.appendChild(button);

button.addEventListener("click", function () {
    localAPI.getAllPostsUsingPromise().then(data => {
        console.log(data);
    }, eMsg => {
        console.error(eMsg);
    })

    // localAPI.getAllPosts((data) => {
    //     console.log(data);
    // }, (eMsg) => {
    //     console.error(eMsg);
    // });
});