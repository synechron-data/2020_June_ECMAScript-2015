// import './1_Functions/1_FnContext';
// import './1_Functions/2_Closure';
// import './1_Functions/3_Currying';

// import './2_Types/1_ObjectCreation';
// import './2_Types/2_ObjectType';
// import './2_Types/3_ObjectMethods';
// import './2_Types/4_CustomType';
// import './2_Types/5_UsingPrototype';
// import './2_Types/6_ES6_Class';
// import './2_Types/7_Compare';
// import './2_Types/8_ES5_Properties';
// import './2_Types/9_ES6_Properties';
// import './2_Types/10_StaticMembers';
// import './2_Types/11_ES5_Inheritance';
// import './2_Types/12_ES6_Inheritance';

// import './3_Collections/1_Array';
// import './3_Collections/2_Map';
// import './3_Collections/3_Set';
// import './3_Collections/4_WeakMap';

// import './4_Iterators/1_Iterators';
// import './4_Iterators/2_Generators';

// import './5_Modules/usage';

// import './6_Promises/1_CreatingPromise';
// import './6_Promises/2_ChainingPromise';
// import './6_Promises/3_PromiseMethods';

import './6_Promises/domHandler';