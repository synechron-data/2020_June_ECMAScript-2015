// function greetings(message, name) {
//     console.log(`${message}, ${name}`);
// }

// greetings("Good Morning", "Abhijeet");
// greetings("Good Morning", "Ramakant");
// greetings("Good Morning", "Pravin");

// function Converter(toUnit, factor, offset, input) {
//     return [((offset + input) * factor).toFixed(2), toUnit].join("");
// }

// console.log(Converter(" INR", 75, 0, 100));
// console.log(Converter(" INR", 75, 0, 150));
// console.log(Converter(" INR", 75, 0, 2900));
// console.log(Converter(" INR", 75, 0, 10000));

// -----------------------------------------------------------------------------

// function greetings(message) {
//     return function (name) {
//         console.log(`${message}, ${name}`);
//     }
// }

// var mGreet = greetings("Good Morning");

// mGreet("Abhijeet");
// mGreet("Ramakant");
// mGreet("Pravin");

// function Converter(toUnit, factor, offset) {
//     return function (input) {
//         return [((offset + input) * factor).toFixed(2), toUnit].join("");
//     }
// }

// var usdToInr = Converter(" INR", 75, 0);

// console.log(usdToInr(100));
// console.log(usdToInr(150));
// console.log(usdToInr(2900));
// console.log(usdToInr(10000));

// ----------------------------------------------------------------------------

// function greetings(message, name) {
//     console.log(`${message}, ${name}`);
// }

// var mGreet = greetings.bind(undefined, "Good Morning");

// mGreet("Abhijeet");
// mGreet("Ramakant");
// mGreet("Pravin");

// function Converter(toUnit, factor, offset, input) {
//     return [((offset + input) * factor).toFixed(2), toUnit].join("");
// }

// var usdToInr = Converter.bind(undefined, " INR", 75, 0);

// console.log(usdToInr(100));
// console.log(usdToInr(150));
// console.log(usdToInr(2900));
// console.log(usdToInr(10000));

// ------------------------------------------------------------------------------
// function add(a, b, c) {
//     console.log(a + b + c);
// }

// function add(a) {
//     return function (b) {
//         return function (c) {
//             console.log(a + b + c);
//         }
//     }
// }

// const add = function (a) {
//     return function (b) {
//         return function (c) {
//             console.log(a + b + c);
//         }
//     }
// }

// const add = a => {
//     return b => {
//         return c => {
//             console.log(a + b + c);
//         }
//     }
// }

const add = a => b => c => {
    console.log(a + b + c);
}

add(2)(3)(4);