var map = new Map();
var wmap = new WeakMap();

map.set('the string', 'his is the value for first key');

// WeakMap - key is always an object
wmap.set({ id: 1 }, 'his is the value for first key');

for (const item of map) {
    console.log(item);
}

// WeakMap is not iterable
// for (const item of wmap) {
//     console.log(item);
// }