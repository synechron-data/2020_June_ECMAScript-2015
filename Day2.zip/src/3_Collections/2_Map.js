var myMap = new Map();

// console.log(myMap);
// console.log(typeof myMap);

const objRef = {};
const fnRef = function () { };

myMap.set('the string', "This is a value for string key");
myMap.set(objRef, "This is a value for object key");
myMap.set(fnRef, "This is a value for function key");

// console.log(myMap);
// console.log(myMap.size);

// console.log(myMap.get('the string'));
// console.log(myMap.get(objRef));
// console.log(myMap.get(fnRef));

// for (const pair of myMap) {
//     console.log(pair);
// }

// for (const [key, value] of myMap) {
//     console.log(`${key}         ${value}`);
// }

// for (const key of myMap.keys()) {
//     console.log(`${key}`);
// }

for (const value of myMap.values()) {
    console.log(`${value}`);
}
