var mySet = new Set();

// console.log(mySet);
// console.log(typeof mySet);

mySet.add(1);
mySet.add(2);
mySet.add(3);
mySet.add(4);
mySet.add(5);

mySet.add(1);
mySet.add(2);
mySet.add(3);

for (const item of mySet) {
    console.log(item);
}
